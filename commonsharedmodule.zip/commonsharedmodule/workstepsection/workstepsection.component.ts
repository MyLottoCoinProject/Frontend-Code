import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workstepsection',
  templateUrl: './workstepsection.component.html'
})
export class WorkstepsectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
