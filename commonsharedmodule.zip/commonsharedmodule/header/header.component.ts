import { Component, OnInit, Input ,ViewChild} from '@angular/core';
import { NgModule } from '@angular/core';
import { FormControl,FormGroup, FormBuilder,Validators } from '@angular/forms';
import { AlertService } from '../../_alert';
import { NgxUiLoaderService, } from 'ngx-ui-loader';
import detectEthereumProvider from '@metamask/detect-provider';
import { PowerballMetamaskService } from '../../services/powerball-metamask.service';
import { type } from 'os';
@Component({
  selector: 'common-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  @Input() cm_message = '';
  @ViewChild('Modalbtn') button; 
  StatusBlockClass: string;
  FormValidateMessage: string;
  FormMessageStatus: Boolean;
  UserTracaction = localStorage.getItem('UserTracaction');
  UserID = localStorage.getItem('UserID');
  ETH_sendTRansactionForm = new FormGroup({
    ETH_addres: new FormControl(''),
    ETH_Rect_address: new FormControl(''),
    ETH_amount: new FormControl(''),
  });
  RopstenNetwork: boolean;
  SendTransButton: boolean;
  CurrentNetwork= {
    NetworkTypeName: '',
    NetworkTypeStatus:false
  };
  //web3: any = window.web3;
  options = {
    autoClose: true,
    keepAfterRouteChange: false 
  };
  
  constructor(public pbMetamask: PowerballMetamaskService, private ngxLoader: NgxUiLoaderService, public alertService: AlertService, public fb:FormBuilder) {
    this.ETH_sendTRansactionForm = this.fb.group({
      ETH_addres: ['', Validators.required],
      ETH_Rect_address: ['', Validators.required],
      ETH_amount: ['', Validators.required],
    })
   }

  ngOnInit(): void {
    // On Network Change Reload Page
    
    this.onNetwirkChangeREload();
    if (this.UserTracaction == 'Yes') {
      this.SendTransButton = true;
      if (this.UserID != null) {
        this.ETH_sendTRansactionForm.controls.ETH_addres.setValue(this.UserID);
      }
    }

  }

  // On Network Change RElaod  Page
  async onNetwirkChangeREload() {
    const ethereum = await detectEthereumProvider();
    if (ethereum) { 
      ethereum.on('chainChanged', (chainId) => {
        window.location.reload();
      });
    }
  }

  //Converting HExa 
  onConvertHexa(value) {
    if (isNaN(value)) {
      if (value != '') {
        const encoded = new Buffer(value).toString('hex');
        const output = '0x' + encoded.toUpperCase();
        console.log(output);
        return output;
      }
    }
    else {
      value = value.toString();
      const encoded = new Buffer(value).toString('hex');
        const output = '0x' + encoded.toUpperCase();
        console.log(output);
        return output;
    } 
  }


  //Only Numaric Enter in input filed
  numericOnly(evnt): boolean {    
    var charC = (evnt.which) ? evnt.which : evnt.keyCode; 
    if (charC == 46) { 
        if (evnt.target.value.indexOf('.') === -1) { 
            return true; 
        } else { 
            return false; 
        } 
    } else { 
        if (charC > 31 && (charC < 48 || charC > 57)) 
            return false; 
    } 
    return true; 
  }

  // Send Transaction
  async onSendTRansaction() {
    // TODO: Use EventEmitter with form value
    const ethereum = await detectEthereumProvider();
    const NetworkTypeCheck = await this.CurrentNetworkType();
    this.FormMessageStatus = true;
    const $this = this;
    const StatusBlock = document.getElementById('cm-status-block');
    const FromThisAddress = this.ETH_sendTRansactionForm.controls.ETH_addres.value;
    const ToThisAddress = this.ETH_sendTRansactionForm.controls.ETH_Rect_address.value;
    const ThisValue = this.ETH_sendTRansactionForm.controls.ETH_amount.value;
    console.log(this.ETH_sendTRansactionForm);
    const ThisValues = this.onConvertHexa(ThisValue);
    console.log(ThisValues);
    if (NetworkTypeCheck.NetworkTypeStatus) {
      ethereum
      .request({
        method: 'eth_sendTransaction',
        params: [
          {
            from: FromThisAddress,
            to: ToThisAddress,
            value: ThisValues,
            gasPrice: '0x09184e72a000',
            gas: '0x5208',
          },
        ],
      })
      .then((txHash) => {
        setTimeout(() => {
          $this.StatusBlockClass = "sucess-status";
          $this.FormValidateMessage = 'Transaction Sucess!';
          $this.Loader('', true);
        })
      })
        .catch((error) => {

          if (error.code === 4001) {
            setTimeout(() => {
              $this.StatusBlockClass = "Warning-status";
              $this.FormValidateMessage = 'Reject Transaction!';
              $this.Loader('', true);
            })
          }
          else if (error.code === -32602) {
            $this.StatusBlockClass = "Warning-status";
            $this.FormValidateMessage = 'Please Check your Ethereum address';
          }
          else if (error.code === -32603) {
            $this.StatusBlockClass = "Warning-status";
            $this.FormValidateMessage = 'Please Check your Recipient address';
          }
      });
    }
    else {
      //this.Loader("Please Chaneg Network Type For Transaction", false);
      this.FormValidateMessage = "Please Chaneg Network Type For Transaction";
    }
   
  }

  // Custom Loader
  Loader(message, reload) {
    if (message != '') { 
      this.alertService.info(message);
    }
    if (reload) {
      setTimeout(() => {
        this.alertService.clear();
        this.ngxLoader.stop();
        window.location.reload();
      }, 3000);
    }
    else {
      setTimeout(() => {
        this.alertService.clear();
        this.ngxLoader.stop();

      }, 3000);
    }
  }

  // Custom Form in Modal
  cmOpenModal() {
    const Modalbtn = document.getElementById('Modal-btn');
    Modalbtn.click();
    const UserPickNumber = JSON.parse(localStorage.getItem('PickNumber'));
    if (UserPickNumber.UserClickNumberStatus == 'Yes') {
      this.ETH_sendTRansactionForm.controls.ETH_amount.setValue(UserPickNumber.UserClickNumberValue);
    }
  }
  // Check If Meta Mask Is install or Not
  async isInstalled() {
    this.pbMetamask.isMetaMaskInstalled();
  }

  async CurrentNetworkType() {
    const ethereum = await detectEthereumProvider();
    const NetworkTypeVersion = ethereum.networkVersion;
    switch (NetworkTypeVersion) {
      case "1":
        this.CurrentNetwork.NetworkTypeName = "Main";
        this.CurrentNetwork.NetworkTypeStatus = false;
        break;
      case "2":
        this.CurrentNetwork.NetworkTypeName = "Morden";
        this.CurrentNetwork.NetworkTypeStatus = false;
       break;
      case "3":
        this.CurrentNetwork.NetworkTypeName = "Ropsten";
        this.CurrentNetwork.NetworkTypeStatus = true;
        break;
      case "4":
        this.CurrentNetwork.NetworkTypeName = "Rinkeby";
        this.CurrentNetwork.NetworkTypeStatus = false;
        break;
      case "42":
        this.CurrentNetwork.NetworkTypeName = "Kovan";
        this.CurrentNetwork.NetworkTypeStatus = false;
        break;
      default:
        this.CurrentNetwork.NetworkTypeName = "Unknown";
        this.CurrentNetwork.NetworkTypeStatus = false;
    }
    return this.CurrentNetwork;
  }
}
